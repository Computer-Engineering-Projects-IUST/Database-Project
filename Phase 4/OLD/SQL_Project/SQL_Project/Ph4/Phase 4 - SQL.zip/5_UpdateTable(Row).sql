update KarbarHaghighi
set Name = 'sayin'
where CodeBoorsi = 1

update SherkatBoorsi
set TedadSahamArzeShode = 50, ArzeshSaham = 1000000 
where Sherkat_id = 1