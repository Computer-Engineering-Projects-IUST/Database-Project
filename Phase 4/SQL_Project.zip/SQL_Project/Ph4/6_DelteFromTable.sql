delete from KarbarHaghighi
where CodeBoorsi = 1

delete from DaftarPishkhan
where CodeDaftar = 1