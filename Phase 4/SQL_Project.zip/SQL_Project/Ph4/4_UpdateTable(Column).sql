ALTER TABLE DaftarPishkhan
ADD NameMasool nvarchar (50);

ALTER TABLE Karbarhaghighi
ADD Email nvarchar(50);